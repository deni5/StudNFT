import { expect } from "chai";
import { ethers } from "hardhat";
import { time, loadFixture } from "@nomicfoundation/hardhat-network-helpers";

// 2026-12-31 23:59:59 UTC+2
const FIRST_END = 1798754399;

async function deploy() {
  const [owner, alice, bob, carol, dave, erin, frank] = await ethers.getSigners();
  const nft = await (await ethers.getContractFactory("StudNFT")).deploy();
  await nft.waitForDeployment();

  // move chain time to a date inside the first contest period (2026-11-20)
  await time.setNextBlockTimestamp(1795132800);
  const contest = await (await ethers.getContractFactory("NFTContest")).deploy(await nft.getAddress(), FIRST_END);
  await contest.waitForDeployment();

  async function mintTo(signer: any, uri = "data:x") {
    const tx = await nft.connect(signer).mint(uri);
    await tx.wait();
    return (await nft.totalSupply()) - 1n;
  }
  async function submit(signer: any) {
    const id = await mintTo(signer);
    await nft.connect(signer).approve(await contest.getAddress(), id);
    await contest.connect(signer).submit(id);
    return id;
  }
  return { owner, alice, bob, carol, dave, erin, frank, nft, contest, mintTo, submit };
}

describe("NFTContest", () => {
  it("opens the first contest at deployment with the configured deadline", async () => {
    const { contest } = await loadFixture(deploy);
    const c = await contest.getContest(1);
    expect(await contest.currentContestId()).to.equal(1n);
    expect(c.endTime).to.equal(BigInt(FIRST_END));
    expect(await contest.isOpen()).to.equal(true);
  });

  it("locks the NFT in the contract on submit", async () => {
    const { alice, nft, contest, submit } = await loadFixture(deploy);
    const id = await submit(alice);
    expect(await nft.ownerOf(id)).to.equal(await contest.getAddress());
    const e = await contest.getEntry(1, 0);
    expect(e.owner).to.equal(alice.address);
    expect(e.tokenId).to.equal(id);
  });

  it("rejects submit of a token the caller does not own", async () => {
    const { alice, bob, nft, contest, mintTo } = await loadFixture(deploy);
    const id = await mintTo(alice);
    await nft.connect(alice).approve(await contest.getAddress(), id);
    await expect(contest.connect(bob).submit(id)).to.be.revertedWith("Contest: not token owner");
  });

  it("enforces the per-wallet entry limit", async () => {
    const { alice, contest, submit } = await loadFixture(deploy);
    for (let i = 0; i < 5; i++) await submit(alice);
    await expect(submit(alice)).to.be.revertedWith("Contest: entry limit reached");
  });

  it("gives one vote per wallet and forbids voting for an own entry", async () => {
    const { alice, bob, carol, contest, submit } = await loadFixture(deploy);
    await submit(alice); // entry 0
    await submit(bob); // entry 1

    await expect(contest.connect(alice).vote(0)).to.be.revertedWith("Contest: cannot vote for own entry");
    await contest.connect(alice).vote(1);
    await expect(contest.connect(alice).vote(0)).to.be.revertedWith("Contest: already voted");

    // a wallet without any entries can vote as well
    await contest.connect(carol).vote(1);
    expect((await contest.getEntry(1, 1)).votes).to.equal(2n);
    expect(await contest.hasVoted(1, alice.address)).to.equal(true);
    expect(await contest.votedFor(1, carol.address)).to.equal(2n); // entryId + 1
    expect((await contest.getContest(1)).voteCount).to.equal(2n);
  });

  it("rejects a vote for a missing entry", async () => {
    const { alice, contest } = await loadFixture(deploy);
    await expect(contest.connect(alice).vote(5)).to.be.revertedWith("Contest: no such entry");
  });

  it("keeps the top 3 ordered; earlier leader wins a tie", async () => {
    const { alice, bob, carol, dave, erin, frank, owner, contest, submit } = await loadFixture(deploy);
    await submit(alice); // 0
    await submit(bob); // 1
    await submit(carol); // 2
    await submit(dave); // 3

    // votes: e1 <- erin, frank (2); e2 <- owner, alice (2); e0 <- bob (1); e3 <- carol (1)
    await contest.connect(erin).vote(1);
    await contest.connect(frank).vote(1);
    await contest.connect(owner).vote(2);
    await contest.connect(alice).vote(2);
    await contest.connect(bob).vote(0);
    await contest.connect(carol).vote(3);

    const winners = await contest.getWinners(1);
    expect(winners.length).to.equal(3);
    expect(winners[0].id).to.equal(1n); // reached 2 votes first
    expect(winners[1].id).to.equal(2n);
    expect(winners[2].id).to.equal(0n); // 1 vote, reached before entry 3
  });

  it("lets a late entry overtake the leaders", async () => {
    const { alice, bob, carol, dave, erin, frank, owner, contest, submit } = await loadFixture(deploy);
    await submit(alice); // 0
    await submit(bob); // 1
    await submit(carol); // 2
    await submit(dave); // 3

    await contest.connect(erin).vote(0);
    await contest.connect(frank).vote(1);
    await contest.connect(owner).vote(2);
    // entry 3 gets 2 votes -> must take first place
    await contest.connect(alice).vote(3);
    await contest.connect(bob).vote(3);

    const w = await contest.getWinners(1);
    expect(w[0].id).to.equal(3n);
    expect(w[0].votes).to.equal(2n);
    expect(w.length).to.equal(3);
  });

  it("blocks submit and vote after the deadline", async () => {
    const { alice, bob, contest, submit, mintTo, nft } = await loadFixture(deploy);
    await submit(alice);
    await time.increaseTo(FIRST_END + 1);
    await expect(contest.connect(bob).vote(0)).to.be.revertedWith("Contest: not open");
    const id = await mintTo(bob);
    await nft.connect(bob).approve(await contest.getAddress(), id);
    await expect(contest.connect(bob).submit(id)).to.be.revertedWith("Contest: not open");
  });

  it("accepts a vote exactly at the deadline (31 Dec inclusive)", async () => {
    const { alice, bob, contest, submit } = await loadFixture(deploy);
    await submit(alice);
    await time.setNextBlockTimestamp(FIRST_END);
    await contest.connect(bob).vote(0);
    expect((await contest.getEntry(1, 0)).votes).to.equal(1n);
  });

  it("cannot finalize or return NFTs while the contest is running", async () => {
    const { alice, contest, submit } = await loadFixture(deploy);
    await submit(alice);
    await expect(contest.finalize()).to.be.revertedWith("Contest: still running");
    await expect(contest.returnEntries(1, [0])).to.be.revertedWith("Contest: still running");
  });

  it("finalizes, opens the next 3-month contest and returns NFTs to their owners", async () => {
    const { alice, bob, carol, nft, contest, submit } = await loadFixture(deploy);
    const a = await submit(alice); // 0
    const b = await submit(bob); // 1
    await contest.connect(carol).vote(1);

    await time.increaseTo(FIRST_END + 100);
    await contest.connect(carol).finalize();

    // the first contest is finalized, winners are kept
    expect((await contest.getContest(1)).finalized).to.equal(true);
    const w = await contest.getWinners(1);
    expect(w.length).to.equal(1);
    expect(w[0].owner).to.equal(bob.address);

    // new contest: 2027-01-01 00:00 (UTC+2) .. 2027-03-31 23:59:59 (UTC+2)
    expect(await contest.currentContestId()).to.equal(2n);
    const c2 = await contest.getContest(2);
    expect(c2.startTime).to.equal(BigInt(FIRST_END + 1));
    expect(c2.endTime).to.equal(1806530399n); // 2027-03-31T23:59:59+02:00
    expect(await contest.isOpen()).to.equal(true);

    // cannot finalize twice
    await expect(contest.finalize()).to.be.revertedWith("Contest: still running");

    // anyone can trigger the return, tokens go back to the original owners only
    await contest.connect(carol).returnEntries(1, [0, 1]);
    expect(await nft.ownerOf(a)).to.equal(alice.address);
    expect(await nft.ownerOf(b)).to.equal(bob.address);
    // idempotent
    await contest.connect(carol).returnEntries(1, [0, 1]);
    expect((await contest.getEntry(1, 0)).returned).to.equal(true);
  });

  it("keeps new contest entries independent from the previous contest", async () => {
    const { alice, bob, nft, contest, submit, mintTo } = await loadFixture(deploy);
    await submit(alice);
    await time.increaseTo(FIRST_END + 100);
    await contest.finalize();

    // votes are per contest: bob can vote again in contest 2
    await contest.connect(bob).vote(0).catch(() => {}); // no entries in contest 2 yet
    const id = await mintTo(alice);
    await nft.connect(alice).approve(await contest.getAddress(), id);
    await contest.connect(alice).submit(id);
    await contest.connect(bob).vote(0);
    expect((await contest.getEntry(2, 0)).votes).to.equal(1n);
    expect(await contest.getEntryCount(1)).to.equal(1n);
    expect(await contest.getEntryCount(2)).to.equal(1n);
  });

  it("rolls through consecutive quarters", async () => {
    const { contest } = await loadFixture(deploy);
    await time.increaseTo(FIRST_END + 100);
    await contest.finalize(); // contest 2: Q1 2027
    const c2 = await contest.getContest(2);
    await time.increaseTo(Number(c2.endTime) + 100);
    await contest.finalize(); // contest 3: Q2 2027 -> ends 2027-06-30 23:59:59+02:00
    const c3 = await contest.getContest(3);
    expect(c3.startTime).to.equal(c2.endTime + 1n);
    expect(c3.endTime).to.equal(1814392799n);
  });

  it("skips fully elapsed periods when nobody finalized for a long time", async () => {
    const { contest } = await loadFixture(deploy);
    // jump to mid-May 2027: Q1 2027 is over already, Q2 is running
    await time.increaseTo(1810000000);
    await contest.finalize();
    const c = await contest.getContest(2);
    expect(await contest.isOpen()).to.equal(true);
    expect(c.endTime).to.be.gt(1810000000n);
  });

  it("lets only the owner change the entry limit", async () => {
    const { owner, alice, contest } = await loadFixture(deploy);
    await expect(contest.connect(alice).setMaxEntriesPerWallet(2)).to.be.reverted;
    await contest.connect(owner).setMaxEntriesPerWallet(2);
    expect(await contest.maxEntriesPerWallet()).to.equal(2n);
    await expect(contest.connect(owner).setMaxEntriesPerWallet(0)).to.be.revertedWith("Contest: invalid limit");
  });
});
